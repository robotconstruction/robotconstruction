# WAVEGO
WAVEGO, An Open Source Bionic Dog-Like Robot Powered By ESP32 &amp; Raspberry Pi.
